<?php return array('dependencies' => array('jquery', 'react', 'react-dom', 'wp-blocks', 'wp-components', 'wp-element', 'wp-i18n'), 'version' => '92bf930ca362cdc4c506');
